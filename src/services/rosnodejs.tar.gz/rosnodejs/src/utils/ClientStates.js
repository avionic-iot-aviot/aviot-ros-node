module.exports = {
  REGISTERING: Symbol('rosnodejs.clientRegistering'),
  REGISTERED: Symbol('rosnodejs.clientRegistered'),
  SHUTDOWN: Symbol('rosnodejs.clientShutdown')
};